# Quinto entregable sugerido: ficha técnica + evidencias

El quinto producto que propongo es una ficha técnica de una página más un anexo corto de pruebas. Así el jurado puede comprobar que el prototipo realmente funciona.

## Contenido obligatorio

- Nombre del proyecto y problema que atiende.
- Dibujo o fotografía rotulada de la maqueta.
- Diagrama de bloques: sensor → Arduino → actuador/interfaz.
- Tabla de componentes y función de cada uno.
- Explicación de cómo funciona, en máximo cinco pasos.
- Tres pruebas con condiciones, valores observados y resultado.
- Una limitación real y una mejora prioritaria.
- Enlace/captura del producto digital.

## Rúbrica orientativa (100 puntos)

| Criterio | Puntos | Qué observar |
|---|---:|---|
| Maqueta y electrónica | 25 | Montaje seguro, lectura o acción real y demostración repetible. |
| Producto digital | 20 | Aporta una función y se conecta o complementa con el prototipo. |
| Bitácora | 15 | Evidencia del proceso, pruebas, errores y decisiones. |
| Pitch | 15 | Problema claro, solución comprensible, impacto y límites honestos. |
| Ficha técnica y validación | 20 | Diagrama, componentes y resultados verificables. |
| Colaboración y respuesta al jurado | 5 | Participación del equipo y respuestas sustentadas. |

## Preguntas para el jurado

1. ¿Qué mide exactamente el sensor y en qué unidades?
2. ¿Qué sucede cuando la lectura supera el umbral?
3. ¿Cómo comprobaron que la medición es razonable?
4. ¿Qué falla conocida tiene su prototipo?
5. ¿Qué cambiarían para llevarlo a una prueba de campo segura?
