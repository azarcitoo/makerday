# Librerías — Alerta Córdoba

No requiere librerías externas. Seleccionar **Arduino Uno** o **Arduino Nano (ATmega328P)** en Arduino IDE. Velocidad serial: 9600 baudios.
