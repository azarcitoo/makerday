# Reto 1 — Alerta Córdoba

## Concepto
Estación de monitoreo de nivel de agua con **Arduino Uno/Nano + sensor ultrasónico JSN-SR04T**. El sensor se fija sobre un recipiente de prueba mirando hacia abajo. Arduino calcula una altura relativa y clasifica el estado como NORMAL, ALERTA o CRITICO. La página web recibe las lecturas por USB.

## Maqueta
Representen un tramo del río Sinú con un canal o tanque transparente. Un puente/poste sostiene el sensor. Incluyan una escala visual de tres colores y una central de monitoreo en pantalla. Se puede conectar más de un Arduino a un computador para representar distintos puntos; cada estación debe tener un `STATION_ID` distinto y su propio puerto USB.

## Arquitectura
JSN-SR04T → Arduino Uno/Nano → USB/Serial → página web multiestación.

## Resultado esperado
La página muestra distancia, porcentaje relativo de llenado, estado y hora de la última lectura por estación.

## Limitaciones
El porcentaje depende de la altura configurada y de la geometría del recipiente. No mide caudal ni predice inundaciones. La maqueta no es una estación hidrológica real.
