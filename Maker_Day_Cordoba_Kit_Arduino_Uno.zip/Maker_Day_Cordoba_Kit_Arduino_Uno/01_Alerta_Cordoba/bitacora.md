# Bitácora — Alerta Córdoba

| Fecha | Actividad/decisión | Prueba y dato observado | Problema | Solución o siguiente paso |
|---|---|---|---|---|
| | Boceto del canal y estación | | | |
| | Montaje del JSN-SR04T | | | |
| | Calibración de altura y umbrales | | | |
| | Integración con el dashboard USB | | | |
| | Prueba final | | | |

Adjuntar fotos del montaje, tabla de lecturas a distintos niveles y captura del panel.
