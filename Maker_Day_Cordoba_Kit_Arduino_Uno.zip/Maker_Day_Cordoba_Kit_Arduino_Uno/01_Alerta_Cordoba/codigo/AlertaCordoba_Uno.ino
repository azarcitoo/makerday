// Alerta Cordoba — Arduino Uno/Nano clasico
#include <string.h>
const byte TRIG_PIN=9, ECHO_PIN=10;
const byte LED_GREEN=3, LED_YELLOW=4, LED_RED=5;
const char STATION_ID[]="SINU_PUNTO_01"; // Cambiar para cada estacion
const float CONTAINER_HEIGHT_CM=50.0;   // Medir desde el sensor hasta el fondo
const float ALERT_PERCENT=40.0;          // Umbral didactico
const float CRITICAL_PERCENT=70.0;       // Umbral didactico
unsigned long lastSample=0;

float readDistanceCm(){
  digitalWrite(TRIG_PIN,LOW); delayMicroseconds(3);
  digitalWrite(TRIG_PIN,HIGH); delayMicroseconds(10);
  digitalWrite(TRIG_PIN,LOW);
  unsigned long duration=pulseIn(ECHO_PIN,HIGH,30000UL);
  if(duration==0) return -1.0;
  return duration*0.0343/2.0;
}

void setup(){
  Serial.begin(9600);
  pinMode(TRIG_PIN,OUTPUT); pinMode(ECHO_PIN,INPUT);
  pinMode(LED_GREEN,OUTPUT); pinMode(LED_YELLOW,OUTPUT); pinMode(LED_RED,OUTPUT);
  Serial.println(F("ALERTA_CORDOBA_LISTA"));
}

void loop(){
  if(millis()-lastSample<1000) return;
  lastSample=millis();
  float distance=readDistanceCm();
  if(distance<0 || distance>CONTAINER_HEIGHT_CM+10){
    digitalWrite(LED_GREEN,LOW); digitalWrite(LED_YELLOW,LOW); digitalWrite(LED_RED,HIGH);
    Serial.print(F("ALERTA_CORDOBA;")); Serial.print(STATION_ID);
    Serial.println(F(";NA;NA;SENSOR_ERROR"));
    return;
  }
  float percent=(CONTAINER_HEIGHT_CM-distance)*100.0/CONTAINER_HEIGHT_CM;
  percent=constrain(percent,0,100);
  const char* state="NORMAL";
  if(percent>=CRITICAL_PERCENT) state="CRITICO";
  else if(percent>=ALERT_PERCENT) state="ALERTA";

  digitalWrite(LED_GREEN,strcmp(state,"NORMAL")==0);
  digitalWrite(LED_YELLOW,strcmp(state,"ALERTA")==0);
  digitalWrite(LED_RED,strcmp(state,"CRITICO")==0);

  // Formato serial: ALERTA_CORDOBA;id;distancia_cm;porcentaje;estado
  Serial.print(F("ALERTA_CORDOBA;")); Serial.print(STATION_ID); Serial.print(';');
  Serial.print(distance,1); Serial.print(';'); Serial.print(percent,1); Serial.print(';');
  Serial.println(state);
}
