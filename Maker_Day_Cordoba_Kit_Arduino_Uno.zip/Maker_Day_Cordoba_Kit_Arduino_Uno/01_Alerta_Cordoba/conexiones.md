# Conexiones — Arduino Uno/Nano

| JSN-SR04T | Arduino Uno/Nano |
|---|---|
| VCC | 5V |
| GND | GND |
| TRIG | D9 |
| ECHO | D10 |

| Indicador | Arduino |
|---|---|
| LED verde (ánodo mediante 220–330 Ω) | D3 |
| LED amarillo (ánodo mediante 220–330 Ω) | D4 |
| LED rojo (ánodo mediante 220–330 Ω) | D5 |

Los cátodos de los LED van a GND. El JSN-SR04T trabaja con lógica de 5 V compatible con Uno/Nano; confirma la ficha de la versión exacta del módulo. Une todas las tierras. Mantén la placa y la protoboard alejadas del agua; solo el transductor impermeable debe quedar cerca del recipiente.

## Ajuste
Mide desde la cara del sensor hasta el fondo del recipiente y modifica `CONTAINER_HEIGHT_CM`. Cambia `STATION_ID` para identificar cada punto de monitoreo. Los umbrales del ejemplo son didácticos y deben probarse en el recipiente, no representan umbrales oficiales del río.
