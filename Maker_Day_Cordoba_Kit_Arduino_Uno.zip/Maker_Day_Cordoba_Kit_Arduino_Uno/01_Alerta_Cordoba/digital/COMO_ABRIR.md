# Abrir la central de Alerta Córdoba

1. Abre esta carpeta `digital` en VS Code.
2. Inicia la extensión **Live Server** desde `index.html` (o sirve la carpeta en `http://localhost`). No abras directamente con `file://` si el navegador bloquea Web Serial.
3. Conecta el Arduino Uno/Nano con un cable USB de datos y carga `codigo/AlertaCordoba_Uno.ino`.
4. Cierra el Monitor Serial del IDE.
5. En la web pulsa **Conectar una estación Arduino**, permite el puerto COM y espera la tarjeta.
6. Para conectar más estaciones, repite el proceso con otros puertos. Cambia `STATION_ID` en cada programa para diferenciarlas.

Web Serial es compatible con versiones actuales de Chrome/Edge en contextos locales seguros como `localhost`. Cada puerto COM solo puede estar abierto por una aplicación a la vez.
