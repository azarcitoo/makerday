const stations=new Map();
const statusEl=document.getElementById('status'), stationsEl=document.getElementById('stations');
function render(){
  if(!stations.size){stationsEl.innerHTML='<div class="empty">Aún no llegan lecturas de Arduino.</div>';return;}
  stationsEl.innerHTML=[...stations.values()].map(s=>{
    const cls=s.state==='CRITICO'?'critical':s.state==='ALERTA'?'alert':s.state==='NORMAL'?'normal':'error';
    return `<article class="card"><div class="row"><h3>${s.id}</h3><span class="pill ${cls}">${s.state}</span></div><div class="metric">${s.percent==null?'—':s.percent.toFixed(1)+'%'}</div><div>Distancia al agua: ${s.distance==null?'sin dato':s.distance.toFixed(1)+' cm'}</div><p class="muted">Última lectura: ${s.time}</p></article>`;
  }).join('');
}
async function connect(){
  if(!('serial' in navigator)){statusEl.textContent='Este navegador no ofrece Web Serial. Prueba Chrome o Edge actualizado en localhost.';return;}
  try{
    const port=await navigator.serial.requestPort(); await port.open({baudRate:9600});
    statusEl.textContent=`Puerto conectado. Estaciones activas: ${stations.size+1}.`;
    const decoder=new TextDecoderStream(); port.readable.pipeTo(decoder.writable).catch(()=>{});
    const reader=decoder.readable.getReader(); let buffer='';
    while(true){const {value,done}=await reader.read();if(done)break;buffer+=value;
      const lines=buffer.split(/\r?\n/);buffer=lines.pop();
      for(const line of lines){const p=line.trim().split(';');if(p.length!==5||p[0]!=='ALERTA_CORDOBA')continue;
        const [tag,id,dist,pct,state]=p;
        stations.set(id,{id,distance:dist==='NA'?null:Number(dist),percent:pct==='NA'?null:Number(pct),state,time:new Date().toLocaleTimeString()});render();
      }
    }
  }catch(e){statusEl.textContent='No se pudo conectar: '+e.message;}
}
document.getElementById('connect').addEventListener('click',connect);render();
