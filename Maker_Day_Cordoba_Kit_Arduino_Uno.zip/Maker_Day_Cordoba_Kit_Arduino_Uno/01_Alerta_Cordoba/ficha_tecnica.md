# Ficha técnica — Alerta Córdoba

- **Problema atendido:** seguimiento didáctico del nivel de agua.
- **Placa:** Arduino Uno/Nano.
- **Sensor:** JSN-SR04T.
- **Indicadores:** tres LED (verde, amarillo y rojo).
- **Comunicación:** USB/Serial a dashboard web.
- **Diagrama:** JSN-SR04T → Arduino → LED + USB → panel de estaciones.
- **Variable calculada:** porcentaje relativo de llenado del recipiente, según altura configurada.
- **Limitación:** prototipo escolar, no instrumento hidrológico ni sistema oficial de alerta.

## Evidencias
Adjuntar tres pruebas con nivel bajo, medio y alto; anotar distancia medida, porcentaje calculado, estado del LED y estado web.
