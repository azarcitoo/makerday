# Materiales — Alerta Córdoba

| Cantidad | Material | Función |
|---:|---|---|
| 1 por estación | Arduino Uno R3 o Nano clásico | Lee el sensor y procesa los umbrales. |
| 1 por estación | JSN-SR04T | Mide la distancia hasta la superficie del agua. |
| 3 | LED verde, amarillo y rojo | Indican normal, alerta y crítico. |
| 3 | Resistencias de 220–330 Ω | Limitan corriente de los LED. |
| 1 | Protoboard y jumpers | Conexiones. |
| 1 | Cable USB de datos | Alimentación y comunicación serial. |
| 1 | Recipiente plástico transparente | Simula el nivel del río. |
| — | Cartón pluma, foamboard, palitos, silicona, regla | Construcción de puente, canal y central. |
| 1 | Computador con Chrome/Edge y VS Code | Ejecuta el dashboard local. |

**Alternativa de prueba en seco:** HC-SR04 en interior, lejos de salpicaduras. No es impermeable. Para la maqueta con agua, mantengan sensor y cableado elevados y protegidos.
