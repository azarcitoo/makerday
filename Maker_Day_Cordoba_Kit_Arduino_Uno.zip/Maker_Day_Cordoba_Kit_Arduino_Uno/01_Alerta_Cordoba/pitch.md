# Pitch — Alerta Córdoba (guion de 60–90 segundos)

1. **Problema:** las crecientes pueden cambiar rápidamente y las comunidades necesitan información clara de puntos críticos.
2. **Usuario:** equipo de monitoreo y comunidades que requieren información local.
3. **Solución:** una estación con Arduino Uno y sensor ultrasónico mide la distancia a la superficie; el sistema calcula un porcentaje relativo y muestra estado normal, alerta o crítico.
4. **Demostración:** variar el nivel de agua en un recipiente y mostrar el cambio de LED y de la tarjeta web.
5. **Impacto y límites:** permite visualizar datos experimentales; no mide caudal, no predice inundaciones y no reemplaza alertas oficiales.
6. **Mejora futura:** proteger la estación, incorporar alimentación autónoma y validar sensores en condiciones controladas.
