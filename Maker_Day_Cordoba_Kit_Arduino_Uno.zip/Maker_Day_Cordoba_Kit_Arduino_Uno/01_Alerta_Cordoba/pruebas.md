# Plan de pruebas — Alerta Córdoba

1. **Nivel bajo:** recipiente con poca agua. Verificar que la lectura cambie y que el LED verde/panel indiquen NORMAL.
2. **Nivel intermedio:** añadir agua lentamente hasta superar el umbral configurado. Confirmar LED amarillo y estado ALERTA.
3. **Nivel alto simulado:** superar el segundo umbral sin desbordar el recipiente. Confirmar LED rojo y estado CRITICO.
4. **Error de medición:** bloquear el eco o retirar el sensor del rango. El sistema debe mostrar SENSOR_ERROR, no una lectura inventada.
5. **Varias estaciones:** conectar dos placas por USB y comprobar tarjetas con IDs distintos.

No probar cerca de ríos, caños o inundaciones reales.
