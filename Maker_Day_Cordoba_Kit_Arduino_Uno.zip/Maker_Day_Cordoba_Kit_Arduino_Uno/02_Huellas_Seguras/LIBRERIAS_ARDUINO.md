# Librerías — Huellas Seguras

En Arduino IDE instala **DHT sensor library by Adafruit** y **Adafruit Unified Sensor** desde Library Manager. `Servo.h` viene con Arduino IDE. Selecciona Arduino Uno o Nano clásico.
