# Reto 2 — Huellas Seguras

## Concepto
Refugio temporal elevado y modular para mascotas. Arduino Uno/Nano lee temperatura y humedad con DHT11 y presencia de agua con un sensor de nivel/fuga analógico. Un servo abre una compuerta de demostración para dispensar una pequeña porción de alimento tras pulsar un botón físico o desde la web por USB.

## Elemento digital
Página para registrar mascotas con código de identificación ficticio, especie, nombre y estado (rescatada, en refugio, reunida/adopción). También muestra temperatura, humedad, presencia de agua y permite enviar el comando de dispensado al Arduino.

## Arquitectura
DHT11 + sensor de agua → Arduino Uno/Nano → indicadores/servo + USB/Serial → página de control y registro.

## Maqueta
Base elevada sobre pilotes, techo impermeable, zona seca, comedero y compartimento de identificación. No probar con animales reales.
