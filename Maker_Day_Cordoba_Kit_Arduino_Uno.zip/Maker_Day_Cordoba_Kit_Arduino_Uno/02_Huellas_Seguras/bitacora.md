# Bitácora — Huellas Seguras

| Fecha | Actividad/decisión | Resultado observado | Problema | Mejora |
|---|---|---|---|---|
| | Boceto de refugio elevado | | | |
| | Montaje DHT11 y sensor de agua | | | |
| | Prueba de compuerta/servo | | | |
| | Creación del registro de mascotas | | | |
| | Integración y prueba final | | | |

Añadir fotos, dimensiones de la maqueta y capturas del registro digital.
