#include <DHT.h>
#include <Servo.h>

#define DHT_PIN 2
#define DHT_TYPE DHT11
const byte WATER_PIN=A0, BUTTON_PIN=4, SERVO_PIN=9;
const byte LED_GREEN=5, LED_RED=6;
const int WATER_THRESHOLD=450; // Calibrar: mirar WATER_RAW en Monitor Serial
const int SERVO_CLOSED=15, SERVO_OPEN=85;
DHT dht(DHT_PIN,DHT_TYPE);
Servo feeder;
unsigned long lastRead=0;

void dispense(){
  feeder.write(SERVO_OPEN); delay(650);
  feeder.write(SERVO_CLOSED); delay(250);
  Serial.println(F("HUELLAS_EVENT;DISPENSED"));
}

void setup(){
  Serial.begin(9600); dht.begin(); feeder.attach(SERVO_PIN); feeder.write(SERVO_CLOSED);
  pinMode(BUTTON_PIN,INPUT_PULLUP); pinMode(LED_GREEN,OUTPUT); pinMode(LED_RED,OUTPUT);
  Serial.println(F("HUELLAS_LISTO"));
}

void loop(){
  if(digitalRead(BUTTON_PIN)==LOW){dispense(); while(digitalRead(BUTTON_PIN)==LOW) delay(10);}
  while(Serial.available()){
    String cmd=Serial.readStringUntil('\n'); cmd.trim();
    if(cmd=="FEED") dispense();
  }
  if(millis()-lastRead>=2000){
    lastRead=millis();
    float h=dht.readHumidity(), t=dht.readTemperature();
    int water=analogRead(WATER_PIN);
    if(isnan(h)||isnan(t)){
      Serial.print(F("HUELLAS;NA;NA;")); Serial.print(water); Serial.println(F(";DHT_ERROR"));
      return;
    }
    bool wet=water>=WATER_THRESHOLD;
    digitalWrite(LED_GREEN,!wet); digitalWrite(LED_RED,wet);
    // HUELLAS;temperatura_C;humedad_pct;lectura_agua;estado
    Serial.print(F("HUELLAS;")); Serial.print(t,1); Serial.print(';');
    Serial.print(h,1); Serial.print(';'); Serial.print(water); Serial.print(';');
    Serial.println(wet?F("AGUA_DETECTADA"):F("SECO"));
  }
}
