# Conexiones — Arduino Uno/Nano

| Componente | Pin Arduino | Alimentación/notas |
|---|---|---|
| DHT11 DATA | D2 | VCC 5V y GND; módulo normalmente ya tiene resistencia pull-up. Sensor suelto requiere 4.7–10 kΩ entre DATA y 5V. |
| Sensor de agua AO | A0 | VCC según módulo (normalmente 5V), GND común. |
| Servo SG90 señal | D9 | Rojo a fuente externa regulada de 5V; marrón/negro a GND. |
| Pulsador | D4 y GND | Se configura INPUT_PULLUP. |
| LED verde (con resistencia) | D5 | Cátodo a GND. |
| LED rojo (con resistencia) | D6 | Cátodo a GND. |

**Servo:** no alimentarlo desde el pin 5V de Arduino. Une el GND de la fuente externa al GND de Arduino. Ajusta el mecanismo para que no se atasque ni fuerce el servo. El sensor de agua solo debe tocar una bandeja pequeña de prueba; mantén la placa y conexiones secas.
