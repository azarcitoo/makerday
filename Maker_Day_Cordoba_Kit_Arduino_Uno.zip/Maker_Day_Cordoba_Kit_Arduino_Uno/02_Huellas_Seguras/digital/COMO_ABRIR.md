# Abrir Huellas Seguras

1. Instala las librerías indicadas en `LIBRERIAS_ARDUINO.md` y carga `codigo/HuellasSeguras_Uno.ino` al Arduino.
2. Ajusta `WATER_THRESHOLD` observando los valores del sensor seco y mojado en Monitor Serial; cierra el Monitor Serial después.
3. Abre `index.html` con Live Server en Chrome/Edge.
4. Pulsa **Conectar Arduino** y elige el puerto COM.
5. Añade registros de mascotas ficticias. La información se conserva en el almacenamiento local del navegador de ese computador.
6. Pulsa **Dispensar porción de prueba** para enviar el comando al servo. Alimenta el servo con una fuente externa regulada de 5 V y GND común.
