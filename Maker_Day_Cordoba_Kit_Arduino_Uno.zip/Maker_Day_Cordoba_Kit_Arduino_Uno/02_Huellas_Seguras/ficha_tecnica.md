# Ficha técnica — Huellas Seguras

- **Placa:** Arduino Uno/Nano.
- **Sensores:** DHT11 y módulo detector de agua analógico.
- **Actuador:** servo SG90 para compuerta demostrativa.
- **Interfaz:** página USB/Serial y registro de mascotas local.
- **Diagrama:** DHT11 + detector de agua → Arduino → LED; Arduino → servo; USB → web.
- **Alimentación:** Arduino por USB; servo con fuente regulada externa 5 V y GND común.
- **Limitación:** maqueta educativa, no refugio certificado ni producto veterinario.

## Evidencias
Tres pruebas: lectura ambiental, detección de agua en bandeja y apertura/cierre del dosificador. Adjuntar registros y fotografías.
