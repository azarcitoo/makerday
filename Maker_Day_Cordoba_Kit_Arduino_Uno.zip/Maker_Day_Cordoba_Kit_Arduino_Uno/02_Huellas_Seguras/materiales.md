# Materiales — Huellas Seguras

| Cantidad | Material | Función |
|---:|---|---|
| 1 | Arduino Uno/Nano | Control. |
| 1 | DHT11 (módulo recomendado) | Temperatura y humedad del refugio. |
| 1 | Sensor de agua/lluvia analógico | Detecta humedad o agua en bandeja de demostración. |
| 1 | Servo SG90 | Abre la compuerta del dosificador. |
| 1 | Pulsador | Comando local de dispensado. |
| 1 | LED rojo y 1 LED verde + resistencias 220–330 Ω | Estado seco/agua detectada. |
| 1 | Fuente regulada externa de 5 V (al menos 1 A recomendado) | Alimentación del servo. |
| 1 | Protoboard, jumpers y cable USB de datos | Conexión/programación. |
| — | Cartón pluma, palitos, plástico, malla, silicona, tela lavable, recipientes | Refugio y dispensador. |
| 1 | Computador con Chrome/Edge y VS Code | Panel y registro web. |

No se necesita alimentar el servo desde el pin 5V del Arduino. La fuente del servo y Arduino deben compartir GND.
