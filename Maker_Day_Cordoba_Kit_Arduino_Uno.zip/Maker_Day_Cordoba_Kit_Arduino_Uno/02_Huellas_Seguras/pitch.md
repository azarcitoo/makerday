# Pitch — Huellas Seguras (60–90 segundos)

1. **Problema:** durante inundaciones, perros y gatos pueden quedar sin refugio seguro.
2. **Solución:** refugio temporal elevado, con monitoreo básico de ambiente y una compuerta dosificadora de demostración.
3. **Tecnología:** Arduino Uno, DHT11, sensor de agua y servo; página para registrar mascotas y consultar su estado.
4. **Demostración:** mostrar lectura ambiental, activar sensor de agua en una bandeja de prueba y abrir el dosificador desde la web.
5. **Impacto y límites:** facilita organizar un refugio temporal a escala; la maqueta no certifica bienestar veterinario ni se prueba con animales.
6. **Mejora futura:** materiales lavables, autonomía energética y sistema de identificación no invasivo.
