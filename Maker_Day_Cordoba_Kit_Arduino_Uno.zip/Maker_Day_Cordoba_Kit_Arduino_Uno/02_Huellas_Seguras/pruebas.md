# Plan de pruebas — Huellas Seguras

1. Registrar temperatura y humedad en el refugio y compararlas con un termómetro/higrómetro de referencia si está disponible.
2. Medir el valor analógico del sensor con la bandeja seca y con una pequeña cantidad de agua; documentar y ajustar `WATER_THRESHOLD`.
3. Activar el servo mediante pulsador y desde la web; comprobar que la compuerta abre/cierra sin atascarse.
4. Registrar una mascota ficticia y cambiar su estado; comprobar que aparece en la tabla.
5. Desconectar el sensor DHT para observar el aviso de error, sin mostrar datos falsos.

No utilizar animales reales en las pruebas.
