# Librerías — Ayuda Conectada

Instala **HX711 Arduino Library** desde Library Manager. Selecciona Arduino Uno o Nano clásico. Antes de usar el sistema, calibra el factor con el programa `CalibrarCelda_Uno.ino`.
