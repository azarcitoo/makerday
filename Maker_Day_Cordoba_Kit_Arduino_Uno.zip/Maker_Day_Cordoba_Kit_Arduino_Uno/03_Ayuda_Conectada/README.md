# Reto 3 — Ayuda Conectada

## Concepto
Centro de distribución a escala con una báscula para pesar cajas de suministros. Una celda de carga conectada a un módulo HX711 entrega lecturas a Arduino Uno/Nano. La página web recibe el peso por USB y permite registrar manualmente entradas y salidas por categoría para llevar un inventario escolar.

## Arquitectura
Celda de carga → HX711 → Arduino Uno/Nano → USB/Serial → página de inventario.

## Maqueta
Construyan zona de recepción, clasificación, estanterías y zona de despacho. Coloquen una plataforma de pesaje estable para paquetes simulados. La página debe mostrar peso instantáneo e inventario restante.

## Limitaciones
La báscula necesita calibración con masa conocida y montaje mecánico correcto. El inventario web es una demostración local y manual; no representa una plataforma oficial de ayuda humanitaria.
