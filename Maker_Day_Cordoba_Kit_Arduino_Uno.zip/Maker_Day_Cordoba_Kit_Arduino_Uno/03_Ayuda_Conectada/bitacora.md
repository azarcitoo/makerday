# Bitácora — Ayuda Conectada

| Fecha | Actividad/decisión | Peso de referencia | Lectura observada | Problema y solución |
|---|---|---:|---:|---|
| | Montaje del centro de acopio | | | |
| | Conexión de celda y HX711 | | | |
| | Calibración de la báscula | | | |
| | Prueba de inventario web | | | |
| | Validación final | | | |

Adjuntar foto del montaje de celda y capturas del panel de inventario.
