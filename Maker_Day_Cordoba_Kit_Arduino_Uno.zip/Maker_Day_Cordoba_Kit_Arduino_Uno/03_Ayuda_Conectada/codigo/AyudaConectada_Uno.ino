#include "HX711.h"
const byte HX_DOUT=3, HX_SCK=2;
// Sustituir por el factor calculado con CalibrarCelda_Uno.ino.
// El signo depende del sentido en que esté conectada la celda.
float CALIBRATION_FACTOR=-7050.0;
HX711 scale;
unsigned long lastSample=0;
void setup(){
  Serial.begin(9600); scale.begin(HX_DOUT,HX_SCK); scale.set_scale(CALIBRATION_FACTOR);
  Serial.println(F("Retira objetos para tarar...")); delay(2000);
  while(!scale.is_ready()){Serial.println(F("HX711_NO_LISTO: revisa cableado")); delay(1000);}
  scale.tare(20); Serial.println(F("AYUDA_LISTO"));
}
void loop(){
  if(millis()-lastSample<500)return; lastSample=millis();
  if(!scale.is_ready()){Serial.println(F("AYUDA;NA;HX711_ERROR"));return;}
  float grams=scale.get_units(5);
  if(grams<0 && grams>-5) grams=0;
  Serial.print(F("AYUDA;")); Serial.print(grams,1); Serial.println(F(";OK"));
}
