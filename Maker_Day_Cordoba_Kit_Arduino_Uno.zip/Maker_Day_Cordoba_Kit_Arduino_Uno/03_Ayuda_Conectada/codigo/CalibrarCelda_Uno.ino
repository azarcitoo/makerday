#include "HX711.h"
const byte HX_DOUT=3, HX_SCK=2;
HX711 scale;
void setup(){
  Serial.begin(9600); scale.begin(HX_DOUT,HX_SCK);
  Serial.println(F("Retira todo de la plataforma.")); delay(2500);
  if(!scale.is_ready()){Serial.println(F("HX711 no detectado: revisa cableado."));return;}
  scale.set_scale(); scale.tare(20);
  Serial.println(F("Coloca una masa conocida y espera la lectura RAW."));
}
void loop(){
  if(!scale.is_ready()){Serial.println(F("HX711_NO_LISTO"));delay(1000);return;}
  Serial.print(F("RAW;")); Serial.println(scale.get_value(20));
  Serial.println(F("Factor = lectura RAW / masa en gramos. Copia el signo y valor en CALIBRATION_FACTOR."));
  delay(2000);
}
