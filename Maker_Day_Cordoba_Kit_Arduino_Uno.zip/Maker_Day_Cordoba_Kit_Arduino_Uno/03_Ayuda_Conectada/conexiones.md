# Conexiones — Arduino Uno/Nano

## HX711 a Arduino

| HX711 | Arduino |
|---|---|
| VCC | 5V (si la placa HX711 admite 5V; revisar módulo) |
| GND | GND |
| DT / DOUT | D3 |
| SCK / CLK | D2 |

## Celda de carga al HX711

En una celda típica de cuatro hilos: rojo = E+, negro = E−, blanco = A− y verde = A+; **confirma los colores del fabricante**, porque no todos siguen el mismo código. Si la celda tiene otros colores, consulta su ficha técnica. No conectes la celda directamente al Arduino.

Fija la celda a una base rígida usando los orificios de montaje previstos y coloca una plataforma que transmita el peso en la dirección indicada. Evita cargas que superen su capacidad nominal.
