# Abrir Ayuda Conectada

1. Instala la librería HX711 indicada. Conecta la celda al HX711 y el HX711 al Arduino.
2. Carga `codigo/CalibrarCelda_Uno.ino`; abre Monitor Serial a 9600, coloca una masa conocida y anota RAW. Calcula `factor = RAW / masa_en_gramos`, conservando el signo. Copia ese factor en `CALIBRATION_FACTOR` del programa principal.
3. Carga `codigo/AyudaConectada_Uno.ino`. Durante el arranque no debe haber peso en la plataforma porque realiza tare.
4. Abre `index.html` con Live Server en Chrome/Edge, cierra Monitor Serial y pulsa **Conectar báscula Arduino**.
5. Registra entradas y salidas de inventario desde la página.

El factor de calibración es propio de cada celda y montaje; no uses el valor de ejemplo sin calibrar.
