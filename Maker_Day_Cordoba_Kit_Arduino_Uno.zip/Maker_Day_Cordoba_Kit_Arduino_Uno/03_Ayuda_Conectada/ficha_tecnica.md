# Ficha técnica — Ayuda Conectada

- **Placa:** Arduino Uno/Nano.
- **Sensor:** celda de carga + HX711.
- **Comunicación:** USB/Serial a página web.
- **Función electrónica:** medir el peso aproximado de una caja.
- **Función digital:** inventario por categoría con entradas y salidas.
- **Flujo:** celda → HX711 → Arduino → USB → panel web.
- **Calibración:** factor obtenido con una masa conocida, específico de cada montaje.

## Evidencias
Documentar lectura sin carga, con masa conocida y con segunda masa. Adjuntar cálculos de error y capturas del inventario.
