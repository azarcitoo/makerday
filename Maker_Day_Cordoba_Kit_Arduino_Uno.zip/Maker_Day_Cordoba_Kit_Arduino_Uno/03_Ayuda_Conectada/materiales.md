# Materiales — Ayuda Conectada

| Cantidad | Material | Función |
|---:|---|---|
| 1 | Arduino Uno/Nano | Procesa lecturas. |
| 1 | Celda de carga de 1–5 kg | Mide peso de una caja de demostración. |
| 1 | Módulo HX711 | Amplifica y digitaliza la señal de la celda. |
| 1 | Plataforma rígida pequeña | Recibe el paquete a pesar. |
| 1 | Protoboard y jumpers | Conexión. |
| 1 | Cable USB de datos | Programación y envío serial. |
| — | Cartón, cajas pequeñas, etiquetas, materiales de estantería | Maqueta del centro de acopio. |
| 1 | Objeto de masa conocida | Calibración (por ejemplo, pesa comercial). |
| 1 | Computador con Chrome/Edge y VS Code | Panel digital. |

La celda debe montarse según su geometría y sin deformar la barra fuera de los puntos de fijación previstos.
