# Pitch — Ayuda Conectada (60–90 segundos)

1. **Problema:** después de una inundación, la ayuda puede desorganizarse y no llegar de forma equilibrada.
2. **Solución:** maqueta de un centro de acopio con estación de pesaje e inventario digital.
3. **Tecnología:** celda de carga + HX711 + Arduino Uno; por USB, el peso se refleja en la página. El inventario registra entradas y salidas.
4. **Demostración:** pesar una caja, registrar la entrada de una categoría y simular una salida.
5. **Impacto y límites:** muestra cómo mejorar la trazabilidad; el registro de unidades se hace manualmente y el sistema es local.
6. **Mejora futura:** códigos QR, usuarios con roles y sincronización central autorizada.
