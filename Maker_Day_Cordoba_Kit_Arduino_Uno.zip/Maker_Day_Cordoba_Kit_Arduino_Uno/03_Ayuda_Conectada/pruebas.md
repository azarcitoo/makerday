# Plan de pruebas — Ayuda Conectada

1. **Cero:** plataforma vacía; revisar que el peso esté cerca de cero tras tare.
2. **Masa de calibración:** colocar una masa conocida y registrar lectura/error porcentual.
3. **Segunda masa:** validar que el peso cambie de forma coherente.
4. **Inventario:** registrar una entrada y una salida; comprobar que las existencias no queden negativas.
5. **Fallo de sensor:** desconectar HX711 solo con el sistema apagado; al reiniciar, comprobar que la interfaz comunique error.

No superar la capacidad nominal de la celda ni cargar lateralmente la barra.
