# Librerías — Zona Segura

Instala **Adafruit ADXL345**, **Adafruit Unified Sensor** y sus dependencias desde Library Manager. Selecciona Arduino Uno o Nano clásico. El bus I²C del Uno usa A4 (SDA) y A5 (SCL).
