# Reto 4 — Zona Segura

## Concepto
Estación didáctica que registra vibraciones con acelerómetro ADXL345 conectado a Arduino Uno/Nano. Calcula un indicador experimental de cambio de aceleración respecto al valor de reposo, activa un LED y un zumbador al superar un umbral configurable y envía mediciones al panel web por USB.

## Arquitectura
ADXL345 → Arduino Uno/Nano → LED/zumbador + USB/Serial → página con gráfica.

## Maqueta
Una base rígida representa el suelo; sobre ella se fija una estructura liviana. El acelerómetro debe quedar sujeto a la base. La demostración consiste en movimientos suaves y controlados sobre una mesa estable.

## Alcance y limitaciones
El prototipo detecta vibraciones que ya están ocurriendo. **No predice terremotos, no es una alerta sísmica oficial, no determina magnitud o epicentro y no garantiza tiempo de evacuación.**
