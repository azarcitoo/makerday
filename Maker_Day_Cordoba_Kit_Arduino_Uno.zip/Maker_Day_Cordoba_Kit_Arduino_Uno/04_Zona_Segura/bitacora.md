# Bitácora — Zona Segura

| Fecha | Actividad/decisión | Lectura en reposo | Prueba de movimiento | Problema y mejora |
|---|---|---:|---:|---|
| | Boceto de base y edificio | | | |
| | Conexión ADXL345 e I²C | | | |
| | Registro de ruido en reposo | | | |
| | Ajuste del umbral | | | |
| | Integración con gráfica web | | | |

Adjuntar esquema de conexiones, fotografías y capturas de gráfica.
