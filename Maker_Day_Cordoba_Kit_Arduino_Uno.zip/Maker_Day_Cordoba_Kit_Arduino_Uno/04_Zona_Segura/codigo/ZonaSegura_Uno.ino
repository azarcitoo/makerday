#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_ADXL345_U.h>
#include <math.h>

const byte LED_PIN=7, BUZZER_PIN=8;
const float ALERT_THRESHOLD_MS2=2.0; // Ajustar tras observar ruido en reposo
Adafruit_ADXL345_Unified accel=Adafruit_ADXL345_Unified(12345);
byte consecutive=0;
unsigned long lastSend=0;

void setup(){
  Serial.begin(115200); pinMode(LED_PIN,OUTPUT); pinMode(BUZZER_PIN,OUTPUT);
  digitalWrite(LED_PIN,LOW); digitalWrite(BUZZER_PIN,LOW); Wire.begin();
  if(!accel.begin()){
    Serial.println(F("ERROR;ADXL345_NO_DETECTADO"));
    while(true){digitalWrite(LED_PIN,!digitalRead(LED_PIN));delay(300);}
  }
  accel.setRange(ADXL345_RANGE_4_G); accel.setDataRate(ADXL345_DATARATE_100_HZ);
  Serial.println(F("ZONA_SEGURA_LISTA"));
}

void loop(){
  sensors_event_t event; accel.getEvent(&event);
  float ax=event.acceleration.x, ay=event.acceleration.y, az=event.acceleration.z;
  float magnitude=sqrt(ax*ax+ay*ay+az*az);
  // Indicador simple respecto a 1 g en reposo. Sensible también a cambios de orientación.
  float dynamicValue=fabs(magnitude-9.81);
  if(dynamicValue>=ALERT_THRESHOLD_MS2){if(consecutive<3)consecutive++;}
  else consecutive=0;
  bool detected=consecutive>=2;
  digitalWrite(LED_PIN,detected?HIGH:LOW); digitalWrite(BUZZER_PIN,detected?HIGH:LOW);
  if(millis()-lastSend>=100){
    lastSend=millis();
    // ZONA;ax;ay;az;indicador;estado
    Serial.print(F("ZONA;")); Serial.print(ax,2); Serial.print(';');
    Serial.print(ay,2); Serial.print(';'); Serial.print(az,2); Serial.print(';');
    Serial.print(dynamicValue,2); Serial.print(';'); Serial.println(detected?F("MOVIMIENTO"):F("ESTABLE"));
  }
  delay(10);
}
