# Conexiones — Arduino Uno/Nano

| Módulo ADXL345 | Arduino Uno | Nota |
|---|---|---|
| VCC | 3.3V o pin indicado por el breakout | Revisa la placa concreta. |
| GND | GND | Tierra común. |
| SDA | A4 mediante adaptador I²C de nivel lógico | No aplicar 5 V al bus de un módulo 3,3 V. |
| SCL | A5 mediante adaptador I²C de nivel lógico | Igual que SDA. |

| Indicador | Pin Arduino |
|---|---|
| LED (ánodo con resistencia 220–330 Ω) | D7 |
| Zumbador activo | D8 y GND (solo si la corriente está dentro de la especificación; si no, usar transistor) |

Fija el sensor firmemente a la base. Mantén los cables cortos. La dirección I²C usual es 0x53; puede ser 0x1D según el estado de SDO.
