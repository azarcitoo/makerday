# Abrir Zona Segura

1. Revisa el voltaje y el nivel lógico del módulo ADXL345. Si no tiene conversor I²C de nivel lógico, instala un adaptador bidireccional entre el Arduino Uno de 5 V y el sensor de 3.3 V.
2. Instala las librerías indicadas y carga `codigo/ZonaSegura_Uno.ino`.
3. Fija el sensor a la maqueta/base. Abre `index.html` con Live Server en Chrome/Edge.
4. Cierra Monitor Serial y pulsa **Conectar Arduino**. Selecciona el puerto COM.
5. Haz movimientos suaves y controlados de la base sobre una mesa estable; observa el indicador y la gráfica.
6. Si hay falsas alertas, registra el valor en reposo y ajusta `ALERT_THRESHOLD_MS2` con evidencia de pruebas.
