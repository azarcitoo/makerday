# Ficha técnica — Zona Segura

- **Placa:** Arduino Uno/Nano.
- **Sensor:** acelerómetro ADXL345 de tres ejes.
- **Comunicación:** I²C (A4/A5) con adaptación de nivel lógico necesaria y USB/Serial a web.
- **Actuadores:** LED y zumbador de baja corriente.
- **Variable:** indicador experimental calculado como diferencia entre magnitud de aceleración y 9.81 m/s².
- **Diagrama:** ADXL345 → Arduino → LED/zumbador + USB → gráfica web.
- **Limitación:** el indicador también responde a cambios de orientación; no es magnitud sísmica ni predicción.

## Evidencias
Registrar 30 segundos en reposo y tres pruebas de movimiento suave. Comparar valores, umbral y falsos positivos.
