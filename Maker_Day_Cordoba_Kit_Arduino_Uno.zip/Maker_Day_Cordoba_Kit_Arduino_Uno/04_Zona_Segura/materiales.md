# Materiales — Zona Segura

| Cantidad | Material | Función |
|---:|---|---|
| 1 | Arduino Uno/Nano | Procesamiento y comunicación serial. |
| 1 | Módulo ADXL345 con adaptación de nivel lógico I²C adecuada para Arduino 5V | Aceleración en tres ejes. |
| 1 | LED + resistencia 220–330 Ω | Alerta visual. |
| 1 | Zumbador activo de baja corriente | Alerta sonora de demostración. |
| 1 | Protoboard, jumpers y cable USB de datos | Conexión. |
| — | Base rígida, cartón pluma/madera/acrílico, maqueta liviana | Simular suelo y edificio. |
| 1 | Computador con Chrome/Edge y VS Code | Panel gráfico. |

**Nota eléctrica:** algunas placas ADXL345 trabajan a 3,3 V y no toleran señales I²C de 5 V. Usa un breakout con regulador y conversor de nivel lógico I²C integrado o un adaptador bidireccional de nivel lógico entre Arduino y el módulo. No conectes SDA/SCL directamente a 5 V si el módulo no es tolerante.
