# Pitch — Zona Segura (60–90 segundos)

1. **Problema:** los movimientos sísmicos pueden afectar viviendas e infraestructura; observar vibraciones ayuda a estudiar el comportamiento de una estructura.
2. **Solución:** estación didáctica que registra aceleración en tres ejes y muestra una alerta experimental cuando supera un umbral.
3. **Tecnología:** ADXL345 + Arduino Uno + LED/zumbador; una página recibe datos por USB y grafica la señal.
4. **Demostración:** comparar la señal en reposo con movimientos suaves de la base.
5. **Alcance:** detecta movimiento que ya ocurre; no predice sismos ni emite alertas oficiales.
6. **Mejora futura:** más puntos de medición, almacenamiento de datos y análisis de vibraciones.
