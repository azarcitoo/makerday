# Plan de pruebas — Zona Segura

1. **Reposo:** dejar la maqueta quieta y registrar el indicador durante 30 segundos.
2. **Movimiento suave:** desplazar muy suavemente la base sobre la mesa y observar si cambia la señal.
3. **Umbral:** ajustar el umbral para reducir falsas alertas sin ocultar la prueba demostrativa; documentar el valor utilizado.
4. **Panel:** confirmar que las lecturas llegan por USB y se dibujan en la gráfica.
5. **Desconexión:** retirar USB y observar que el panel deja de recibir datos; no debe afirmar que la estación sigue monitoreando.

No sacudir violentamente el equipo ni usarlo para ensayar una emergencia real.
