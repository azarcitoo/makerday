# Maker Day Córdoba — Kit de asesoría (versión Arduino Uno/Nano)

Este paquete contiene una propuesta práctica para los cuatro retos. **Toda la electrónica está diseñada para Arduino Uno R3 o Arduino Nano clásico (ATmega328P), no ESP32.** No se necesita Wi‑Fi ni Bluetooth.

## Los cinco entregables sugeridos

1. **Maqueta funcional:** escenario físico con una lectura o acción electrónica comprobable.
2. **Elemento digital:** página web, panel o registro que complemente el prototipo. En este kit las páginas leen el puerto USB/serial del Arduino mediante Web Serial.
3. **Bitácora:** registro de ideas, bocetos, conexiones, pruebas, fallos, cambios y aprendizajes.
4. **Pitch:** presentación oral breve con problema, usuarios, solución, demostración, impacto y próximos pasos.
5. **Ficha técnica y evidencias de validación:** diagrama, componentes, principio de funcionamiento, tres pruebas documentadas, resultados, limitaciones y mejoras. Pueden añadir un video corto.

## Cómo se conecta el elemento digital

- Conecten el Arduino al computador con un **cable USB de datos**.
- Abran la carpeta `digital` del reto con Visual Studio Code y ejecuten `index.html` usando Live Server, o un servidor local equivalente.
- Usen Google Chrome o Microsoft Edge actualizado. Pulsen **Conectar Arduino** y seleccionen el puerto COM correspondiente.
- El navegador y el Arduino se comunican directamente por USB/serial. No se requiere Flask, Python, Wi‑Fi ni Internet una vez abierta la página.
- Cierren el Monitor Serial del Arduino IDE antes de conectar la página: un puerto COM normalmente solo puede estar abierto por una aplicación a la vez.
- Si Windows no muestra un puerto COM, revisen el cable USB de datos y el controlador USB‑serial de la placa.

## Placas y compatibilidad

- Placa sugerida: Arduino Uno R3.
- Alternativa: Arduino Nano clásico ATmega328P. El mapeo de pines es el mismo.
- No seleccionar Nano Every, ESP32 ni otras placas sin adaptar el programa.
- Alimentar la placa por USB durante la demostración. Servos y módulos que consumen más corriente deben usar una fuente regulada aparte, con GND común.

## Precauciones importantes

- Los prototipos son educativos, no sistemas certificados de alerta de inundación o sismos. No deben usarse para decisiones reales de evacuación.
- No prueben sensores en ríos, caños, calles inundadas ni cerca de estructuras inestables. Usen recipientes pequeños y controlados.
- No prueben el refugio con animales reales. El dosificador es una demostración mecánica, no un sistema veterinario.
- No conecten motores, servos o cargas de corriente alta directamente a un pin digital. Revisen las recomendaciones particulares de cada reto.
- No publiquen teléfonos, direcciones ni datos personales reales de familias o dueños de mascotas. Usen datos ficticios en las demostraciones.

## Contenido de cada carpeta

Cada reto contiene `README.md`, `materiales.md`, `conexiones.md`, `LIBRERIAS_ARDUINO.md`, `codigo/`, `digital/`, `bitacora.md`, `pitch.md`, `ficha_tecnica.md` y `pruebas.md`.
